INSERT INTO usuario
VALUES
(1, 'vinicius', '123');